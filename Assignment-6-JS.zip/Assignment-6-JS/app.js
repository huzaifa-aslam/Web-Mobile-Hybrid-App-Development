// Assignment # 21-25

// q# 3

// var str="Pakistan"

//     document.write(str.indexOf("n"))

// q# 4

// str="Hello World"
// document.write(str.lastIndexOf("l"))


// Q# 5

// str="Pakistani"
// document.write(str.charAt(3))

// Q# 7

// str="Hyderabad"
// document.write(str.replace("Hyder","Islam"))



// Q# 8

// str='Ali and Sami are best friends. They play cricket and football together.'

// document.write(str.split("and").join("&"))


// Q# 9

// var str="472"
// var con=Number(str)
// console.log(con)
// console.log(typeof(con))


// Q# 11
// var con;
// var input=prompt("enter stirng in lowercase")
// con=input[0].toUpperCase()


// var sl=input.slice(1)
// document.write(con.concat(sl))



// Q# 12

// var n1=35.36
// var str=String(n1)
// var rep=str.replace(".","")
// console.log(rep)


// Q# 13

// var input=prompt("enter your name");
// var name=input;
// for (var i=0;i<=name.length-1;i++){
//     if(name[i] ===(String.fromCharCode(44) ) ||name[i] ===(String.fromCharCode(46) )  ||name[i] ===(String.fromCharCode(33) ) || name[i] ===(String.fromCharCode(64) )){
//         alert("please enter valid name")
//     }

// }






// Q# 14


// var arr=['cake','apple','cookie','chips','patties'];
// var input=prompt("enter your order").toLowerCase()
// var com=input.slice()
// for(var i=0;i<=arr.length-1;i++){
//     if(arr[i]===input){
//         alert(`${input} is available at index ${i}`)
//         break;
//     }
// }


// Q# 17

// var input=prompt("enter any name")
// var copy=input.slice(-1)
// console.log(copy)

// Q# 18

// var str="The quick brown fox jumps over the lazy dog";
// var lower=str.toLowerCase()
// var con=lower.split(" ")

// var count=0
// for(var i=0;i<=con.length-1;i++){
// if(con[i]==="the")
// {
//     count++
// }
// }
// document.write(count)


// Assignment # 26-30

// Q# 1




// Assignment # 35-38

// 1-

// function dateAndTime(){
//     var date=new Date()
//     document.write(date)
// }
// dateAndTime()

// 2-

// function greeting(fname,lname){
//     document.write(`Welcome ${fname} ${lname}`)
// }
// greeting('Huzaifa','Aslam')

// 3-

// function sum(){
//     var c=+prompt('Enter first number')
//     var d=+prompt("Enter second number")
//     return c+d
// }
// document.write(sum())

// 4-

// function calculator(c,d,f) {
//   var c = +prompt("Enter first number");
//   var d = +prompt("Enter second number");
//   var f = prompt("Enter operator");
//   switch (f) {
//     case "+":
//       return c + d;
//       break;
//     case "-":
//       return c - d;
//       break;
//     case "*":
//       return c * d;
//       break;
//     case "/":
//       return c / d;
//       break;
//       default:
//           return "Try Again"

//   }
//   return c + d;
// }
// document.write(calculator(2,4,"-"));

// 5-

// function square(a,b){
// return Math.pow(a,b)
// }
// document.write(square(2,3))

// 6-
// function factorial(){
//     var inputNumber = prompt('Please enter an integer');
//     var total = 1;

//     for (i = 0; i < inputNumber; i++){
//         total = total * (inputNumber - i);
//     }

//     console.log(inputNumber + '! = ' + total);
// }
// factorial()

// 7-

// function counting(){
//     var a=prompt('enter start number')
//     var b=prompt(`enter end number`)
//     for(var i=a;i<=b;i++){
//         document.write(`${i} <br>`)
//     }
// }
// counting()

// 8-

// function outerFunc(){
//     var a=+prompt('enter the value of base ')
//     var b=+prompt(`enter the value of perb`)
//     var hyp=a*a+b*b;

//  function result(){
//     document.write(Math.sqrt(hyp))
//  }
//  result()
// }
// outerFunc()

// 9-
// function area (widht,height){
//     var cal=widht*height
//     document.write(cal)
// }
// area(2,4)

// 10-

// function palindrom(string) {
//   var str = string;
//   var palindrom="";

//     for(var i=str.length-1;i>=0;i--){
//         palindrom+=str[i]

//     }
//     if(str===palindrom){
//         console.log(`${str} is Palindrome word`)
//     }

// }
// palindrom("civic");

// 11-

// function changeCase(str){
// var conStr=str
// var count=0;
// var ind=conStr.indexOf(" ")
// for(var i=0;i<=conStr.length;i++){
// if(conStr[i]==" "){
//     conStr[i+1].toUpperCase();


// }
// }
// console.log(ind)


// }
// changeCase('the quick brown fox');
